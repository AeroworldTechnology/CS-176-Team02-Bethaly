﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestSwapAB;

namespace SwapIntAB
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            //Arrage
            int firstValue = 125;
            int secondValue = 37;

            //Act

            int swapResult =SwapClass.SwapAandB(firstValue, secondValue);

            //Assert
            Assert.AreEqual(swapResult, 37);
        }
    }
}
