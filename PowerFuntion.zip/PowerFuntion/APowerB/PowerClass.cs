﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APowerB
{
    public class PowerClass
    {
        public static int AtoPowerB(int xValue, int nValue)
        {
            int calcValue = 1;

            if (xValue != 0 && nValue != 0)
            {
                for (int i = 0; i < nValue; i++)
                {
                    calcValue = calcValue * xValue;
                }
            }
            else
            {
                if (xValue == 0)
                {
                    // Zero to any power is always zero, except...
                    calcValue = 0;
                }
                if (nValue == 0)
                {
                    // Any number raised to zero power is 1, including zero.
                    calcValue = 1;
                }
            }
            return calcValue;
        }
    }
}
